# ModbusRTU_Slave
A library package commonly used by Modbus.
Targeted to Arduino Mega2560.

### 1.0.0 (2017-06-12)
Initial release. Includes ModbusRTU_Slave

### 1.0.1 (2017-06-12)
Re release. For arduino library.
